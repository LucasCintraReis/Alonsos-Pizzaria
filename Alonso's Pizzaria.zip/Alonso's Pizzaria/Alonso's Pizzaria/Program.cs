﻿using Alonso_s_Pizzaria;

class Program
{
    static List<Produto> cardapio = new List<Produto>();
    static Pedido pedidoAtual = new Pedido();

    static void Main()
    {
        CarregarCardapio();

        Console.WriteLine("========================================");
        Console.WriteLine("   BEM-VINDO À ALONSO'S PIZZARIA");
        Console.WriteLine("========================================");

        bool sair = false;
        while (!sair)
        {
            Console.WriteLine("\n--- MENU PRINCIPAL ---");
            Console.WriteLine("1 - Visualizar Produtos / Adicionar ao Pedido");
            Console.WriteLine("2 - Visualizar Itens do Pedido");
            Console.WriteLine("3 - Remover Itens do Pedido");
            Console.WriteLine("4 - Finalizar Pedido");
            Console.WriteLine("0 - Sair");
            Console.Write("Escolha: ");

            string? opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    MenuProdutos();
                    break;
                case "2":
                    pedidoAtual.Exibir();
                    break;
                case "3":
                    RemoverItem();
                    break;
                case "4":
                    FinalizarPedido();
                    break;
                case "0":
                    sair = true;
                    Console.WriteLine("Até mais!");
                    break;
                default:
                    Console.WriteLine("Opção inválida.");
                    break;
            }
        }
    }

    static void CarregarCardapio()
    {
        cardapio.Add(new Pizza { Id = 1, Nome = "Mussarela", Tamanho = "P", Preco = 29.90, Descricao = "Molho, mussarela e orégano" });
        cardapio.Add(new Pizza { Id = 2, Nome = "Calabresa", Tamanho = "P", Preco = 32.90, Descricao = "Molho, mussarela, calabresa e cebola" });
        cardapio.Add(new Pizza { Id = 3, Nome = "Frango com Catupiry", Tamanho = "P", Preco = 34.90, Descricao = "Molho, frango desfiado e catupiry" });
        cardapio.Add(new Pizza { Id = 4, Nome = "Portuguesa", Tamanho = "P", Preco = 36.90, Descricao = "Molho, presunto, ovo, cebola, azeitona e ervilha" });

        cardapio.Add(new Pizza { Id = 5, Nome = "Mussarela", Tamanho = "M", Preco = 39.90, Descricao = "Molho, mussarela e orégano" });
        cardapio.Add(new Pizza { Id = 6, Nome = "Calabresa", Tamanho = "M", Preco = 42.90, Descricao = "Molho, mussarela, calabresa e cebola" });
        cardapio.Add(new Pizza { Id = 7, Nome = "Frango com Catupiry", Tamanho = "M", Preco = 44.90, Descricao = "Molho, frango desfiado e catupiry" });
        cardapio.Add(new Pizza { Id = 8, Nome = "Portuguesa", Tamanho = "M", Preco = 46.90, Descricao = "Molho, presunto, ovo, cebola, azeitona e ervilha" });

        cardapio.Add(new Pizza { Id = 9, Nome = "Mussarela", Tamanho = "G", Preco = 49.90, Descricao = "Molho, mussarela e orégano" });
        cardapio.Add(new Pizza { Id = 10, Nome = "Calabresa", Tamanho = "G", Preco = 52.90, Descricao = "Molho, mussarela, calabresa e cebola" });
        cardapio.Add(new Pizza { Id = 11, Nome = "Frango com Catupiry", Tamanho = "G", Preco = 54.90, Descricao = "Molho, frango desfiado e catupiry" });
        cardapio.Add(new Pizza { Id = 12, Nome = "Portuguesa", Tamanho = "G", Preco = 56.90, Descricao = "Molho, presunto, ovo, cebola, azeitona e ervilha" });

        cardapio.Add(new Bebida { Id = 13, Nome = "Coca-Cola 350ml", Preco = 6.00, Descricao = "Lata" });
        cardapio.Add(new Bebida { Id = 14, Nome = "Coca-Cola 2L", Preco = 12.00, Descricao = "Garrafa" });
        cardapio.Add(new Bebida { Id = 15, Nome = "Guaraná Antarctica 350ml", Preco = 5.50, Descricao = "Lata" });
        cardapio.Add(new Bebida { Id = 16, Nome = "Água Mineral 500ml", Preco = 3.00, Descricao = "Com gás ou sem gás" });
        cardapio.Add(new Bebida { Id = 17, Nome = "Suco de Laranja 500ml", Preco = 8.00, Descricao = "Natural" });
    }

    static void MenuProdutos()
    {
        Console.WriteLine("\n--- CARDÁPIO ---");
        Console.WriteLine("\nPIZZAS:");
        foreach (var produto in cardapio.Where(p => p.Categoria == "Pizza"))
        {
            Console.WriteLine(produto);
        }

        Console.WriteLine("\nBEBIDAS:");
        foreach (var produto in cardapio.Where(p => p.Categoria == "Bebida"))
        {
            Console.WriteLine(produto);
        }

        Console.Write("\nDigite o ID do produto (ou 0 para voltar): ");
        if (!int.TryParse(Console.ReadLine(), out int id) || id == 0)
            return;

        var produtoSelecionado = cardapio.FirstOrDefault(p => p.Id == id);
        if (produtoSelecionado == null)
        {
            Console.WriteLine("Produto não encontrado.");
            return;
        }

        Console.Write($"Quantidade de {produtoSelecionado.Nome}: ");
        if (!int.TryParse(Console.ReadLine(), out int quantidade) || quantidade <= 0)
        {
            Console.WriteLine("Quantidade inválida.");
            return;
        }

        Console.Write("Observação (Enter para nenhuma): ");
        string? observacao = Console.ReadLine();

        pedidoAtual.AdicionarItem(produtoSelecionado, quantidade, observacao ?? "");
        Console.WriteLine($"\n{quantidade}x {produtoSelecionado.Nome} adicionado(s) ao pedido!");
    }

    static void RemoverItem()
    {
        if (pedidoAtual.Itens.Count == 0)
        {
            Console.WriteLine("Pedido vazio. Nada para remover.");
            return;
        }

        pedidoAtual.Exibir();
        Console.Write("\nDigite o número do item para remover (ou 0 para cancelar): ");
        if (!int.TryParse(Console.ReadLine(), out int numero) || numero == 0)
            return;

        if (pedidoAtual.RemoverItem(numero - 1))
            Console.WriteLine("Item removido.");
        else
            Console.WriteLine("Número inválido.");
    }

    static void FinalizarPedido()
    {
        if (pedidoAtual.Itens.Count == 0)
        {
            Console.WriteLine("Pedido vazio. Adicione itens antes de finalizar.");
            return;
        }

        Console.WriteLine("\n========== RESUMO DO PEDIDO ==========");
        pedidoAtual.Exibir();
        Console.WriteLine("======================================");
        Console.Write("\nConfirmar pedido? (S/N): ");
        string? confirmacao = Console.ReadLine()?.ToUpper();

        if (confirmacao == "S")
        {
            Console.WriteLine("\nPedido finalizado com sucesso!");
            Console.WriteLine($"Valor total: R$ {pedidoAtual.Total:F2}");
            Console.WriteLine("Obrigado pela preferência. Bom apetite!");
            pedidoAtual.Limpar();
        }
        else
        {
            Console.WriteLine("Pedido não finalizado. Você pode continuar editando.");
        }
    }
}
