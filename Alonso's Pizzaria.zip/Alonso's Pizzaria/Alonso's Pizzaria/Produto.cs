﻿namespace Alonso_s_Pizzaria
{
    public abstract class Produto
    {
        public int Id { get; set; }
        public string Nome { get; set; } = "";
        public string Descricao { get; set; } = "";
        public double Preco { get; set; }
        public abstract string Categoria { get; }
        public virtual string Tamanho { get; set; } = "";

        public abstract string ObterDescricao();

        public override string ToString()
        {
            return $"{Id} - {Nome}{(string.IsNullOrEmpty(Tamanho) ? "" : $" ({Tamanho})")} - R$ {Preco:F2} | {ObterDescricao()}";
        }
    }
}
