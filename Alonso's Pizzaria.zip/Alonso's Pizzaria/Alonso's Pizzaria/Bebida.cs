﻿namespace Alonso_s_Pizzaria
{
    public class Bebida : Produto
    {
        public override string Categoria => "Bebida";

        public override string ObterDescricao()
        {
            return $"Bebida: {Descricao}";
        }
    }
}
