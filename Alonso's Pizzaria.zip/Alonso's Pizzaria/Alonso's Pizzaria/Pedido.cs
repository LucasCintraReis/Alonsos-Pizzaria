﻿using Alonso_s_Pizzaria;

namespace Alonso_s_Pizzaria
{
    public class Pedido
    {
        public List<ItemPedido> Itens { get; set; } = new List<ItemPedido>();

        public double Total => Itens.Sum(i => i.Subtotal);

        public void AdicionarItem(Produto produto, int quantidade, string observacao = "")
        {
            var itemExistente = Itens.FirstOrDefault(i => i.Produto.Id == produto.Id && i.Observacao == observacao);
            if (itemExistente != null)
            {
                itemExistente.Quantidade += quantidade;
            }
            else
            {
                Itens.Add(new ItemPedido
                {
                    Produto = produto,
                    Quantidade = quantidade,
                    Observacao = observacao
                });
            }
        }

        public bool RemoverItem(int indice)
        {
            if (indice >= 0 && indice < Itens.Count)
            {
                Itens.RemoveAt(indice);
                return true;
            }
            return false;
        }

        public void Limpar()
        {
            Itens.Clear();
        }

        public void Exibir()
        {
            if (Itens.Count == 0)
            {
                Console.WriteLine("Nenhum item no pedido ainda.");
                return;
            }

            Console.WriteLine("\n=== ITENS DO PEDIDO ===");
            for (int i = 0; i < Itens.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Itens[i]}");
            }
            Console.WriteLine($"\nTOTAL: R$ {Total:F2}");
        }
    }
}
