﻿namespace Alonso_s_Pizzaria
{
    public class Pizza : Produto
    {
        public override string Categoria => "Pizza";
        public override string Tamanho { get; set; } = "";

        public override string ObterDescricao()
        {
            return $"Pizza {Tamanho}: {Descricao}";
        }
    }
}
