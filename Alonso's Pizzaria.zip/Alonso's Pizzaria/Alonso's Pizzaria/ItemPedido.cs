﻿namespace Alonso_s_Pizzaria
{
    public class ItemPedido
    {
        public Produto Produto { get; set; } = null!;
        public int Quantidade { get; set; }
        public string Observacao { get; set; } = "";

        public double Subtotal => Produto.Preco * Quantidade;

        public override string ToString()
        {
            string obs = string.IsNullOrEmpty(Observacao) ? "" : $" (Obs: {Observacao})";
            return $"{Quantidade}x {Produto.Nome} {(string.IsNullOrEmpty(Produto.Tamanho) ? "" : "(" + Produto.Tamanho + ")")} - R$ {Subtotal:F2}{obs}";
        }
    }
}
